# Pacman Template

This repository is a template for students. The cli will help you with creating agents, running your code and packaging submissions.

Thanks to RMIT University and UC Berkeley for open-sourcing their code. See [3rd-party Code](#3rd-party-code) for a brief description of changes and references to the work we build upon.

## Code of Conduct
> **_Please do not distribute or post solutions to any of the projects anywhere online._**

### Academic Integrity

This is an advanced course, so we expect full professionalism and ethical conduct.  Plagiarism is a serious issue. **We trust you; please don't let us down**. The staff take academic misconduct very seriously. Suspected collusion or plagiarism will be dealt with according to the **University Academic Integrity policy**.

We expect every student taking this course to adhere to it **Code of Honour** under which every learner-student should:

* Submit their own original work.
* Do not share answers with others.
* Report suspected violations.
* Not engage in any other activities that will dishonestly improve their results or dishonestly improve or damage the results of others.

Unethical behaviour is extremely serious and consequences are painful for everyone. We expect enrolled students/learners to take full **ownership** of your work and **respect** the work of teachers and other students.

## Quickstart

Let's get you started.

_This short guide should work independent of your OS but is only thoroughly tested on Linux (Fedora 34 to be precise). We expect you to be familiar with basic command-line
commands._

### Local setup
First, clone the repository and install its dependencies. We recommend you to get familiar with git if you aren't, yet. It helps collaboration with your team!
```bash
pipenv install
```

Now, generate a new agent
```bash
pipenv run python cli.py --createNewAgent
```
This will guide you through creating a new agent and tell you where it has been placed.

Finally, to package your agent run
```bash
pipenv run python cli.py --createSubmission
```
where the last parameter is the path to the directory containing your agent module.

To run a single-player game using the greedyAgent use the following command. You can also use a `keyboardAgent` to manually control Pacman.
```shell
pipenv run python cli.py -m pacman -p greedyAgent -l defaultPacman
```

To run a capture game run
```shell
pipenv run python cli.py -m capture -l defaultCapture
```

Checkout [guide.md](guide.md) for instructions and explanations on how to run pacman games and in different modes using your agents. 

See [CONTEST.md](CONTEST.md) file for detailed information and documentation about the code of the contest.

## Contributing

If you want to contribute enhancements, please open an issue which includes a problem statement before filing a pull-request.

### 3rd-party code
This code builds in large parts upon [RMIT University's enhancements](https://github.com/AI4EDUC/pacman-contest-agent) of [UC Berkeley's Pacman Capture the Flag](http://ai.berkeley.edu/contest.html) competition code. We are very grateful for the projects' members hard work.

This version includes the following changes:
* Refactoring into multiple modules
* Add tooling for bootstrapping new agents
* Add tooling for creating submissions. NB: submissions created this way are not backwards compatible (yet). We do not use the existing competition cluster but develop a separate submission and competition scheduling system.
* Use json for serializing games instead of pickle files for enhanced interoperability.


## Original Licensing Information from UC Berkeley

Please do not distribute or publish solutions to this project. You are free to use and extend these projects for educational purposes. The Pacman AI projects were developed at UC Berkeley, primarily by
John DeNero (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).  Student side autograding was added by Brad Miller, Nick Hay, and Pieter Abbeel (pabbeel@cs.berkeley.edu).

For more info, see [here](http://inst.eecs.berkeley.edu/~cs188/sp09/pacman.html).

You are free to use or extend these projects for educational purposes provided that 

1. you do not distribute or publish solutions,
2. you retain this notice,
3. you provide clear attribution to UCB Berkeley, including a link to http://ai.berkeley.edu.
