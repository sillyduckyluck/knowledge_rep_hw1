### Python Imports
from optparse import Option
import sys
import os

from pacman.core import capture
import importlib


### Internal Imports
from pacman.core import pacman
from pacman.core.cliUtil import parseAgentName, parseTeamName
from pacman.core.agentCreator import createAgent
from pacman.core.teamCreator import createTeam
from pacman.core.submissionCreator import createSubmission
from pacman.teams import captureTeams
from pacman.agents import pacmanAgents
### External Imports


#############################################################################
###                          Top Level Functions                          ###
#############################################################################


#############################################################################
###                         Command Line Parsing                          ###
#############################################################################
def default(str) -> str:
    return str + ' [Default: %default]'

def optionsToKwargs(options:dict):
    ret = ['fromCli']
    for key in options.keys():
        if(key.__len__() > 0):
            ## Special treatment for boolean arguments (they dont get parameters and are false by default)
            if(type(options[key]) == bool):
                if(options[key]):
                    if(key.__len__() == 1):
                        ret.append('-'+key)
                    else:
                        ret.append('--'+key)
                    continue
                
            ## Every non-bool argument
            else:
                ## Making sure that the parameter provided is not 'None'
                if(options[key] != None):
                    if(key.__len__() == 1):
                        ret.append('-'+key)
                    else:
                        ret.append('--'+key)
                    ret.append(str(options[key]))
        else:
            raise Exception('optionsToKwargs method failed: One keyword is empty')
    return ret

def generateOptionsForMode(mode:str, optionsDict:dict):
    '''
    Removes all options that cannot be read by the given mode and returns a dict containing only the remaining options
    '''
    ret:dict = dict()
    allowedOptions:list = None
    
    ## TODO: get the options from the optionParser instead to be more modular
    if mode == 'pacman':
        allowedOptions = ['numGames','layout','pacman','textGraphics', 'quietTextGraphics', 'ghosts', 'numGhosts','fixRandomSeed', 'record', 'replay', 'agentArgs', 'numTraining', 'frameTime', 'maxIterations','catchExceptions', 'timeout']
    elif mode == 'capture':
        allowedOptions = ['red', 'blue', 'redName', 'blueName', 'redOpts', 'blueOpts', 'keys0','keys1','keys2', 'keys3', 'layout', 'textGraphics', 'quietTextGraphics', 'superQuiet', 'zoom', 'maxIterations', 'numGames', 'fixRandomSeed', 'setRandomSeed', 'record', 'recordLog', 'replay', 'replayq', 'delayStep', 'numTraining', 'catchExceptions']
    else:
        raise Exception('Command Line Input not understood: Unknown Mode '+ str(mode))
    for optionKey in allowedOptions:
        if optionsDict.get(optionKey) != None:
            ret[optionKey] = optionsDict.get(optionKey)
    return ret

def readCommand(argv):
    '''reads the given command and exectutes it. Can both bootstrap new agents and start games of pacman or capture'''
    from optparse import OptionParser
    
    DIR_SCRIPT = sys.path[0]
    parser:OptionParser = OptionParser()
    
    ## Commands for agent-bootstrapping
    parser.add_option('--createNewAgent', action="store_true", dest="createNewAgent", default=False, help='Creates a new agent-template in the /agents folder')
    
    ## Commands for pacman & capture games
    parser.add_option('-m', '--mode', dest='mode', type='str', help='Which mode to start the game in. Either \'pacman\' or \'capture\'', default='pacman')
    parser.add_option('-n', '--numGames', dest='numGames', type='int',
                      help=default('the number of GAMES to play'), metavar='GAMES', default=1)
    parser.add_option('-l', '--layout', dest='layout',
                      help=default('the LAYOUT_FILE from which to load the map layout'),
                      metavar='LAYOUT_FILE')
    parser.add_option('-p', '--pacman', dest='pacman',
                      help=default('the agent TYPE in the pacmanAgents module to use'),
                      metavar='TYPE', default='KeyboardAgent')
    parser.add_option('-t', '--textGraphics', action='store_true', dest='textGraphics',
                      help='Display output as text only', default=False)
    parser.add_option('-q', '--quietTextGraphics', action='store_true', dest='quietTextGraphics',
                      help='Generate minimal output and no graphics', default=False)
    parser.add_option('-g', '--ghosts', dest='ghosts',
                      help=default('the ghost agent TYPE in the ghostAgents module to use'),
                      metavar = 'TYPE', default='RandomGhost')
    ## TODO: Change numghosts to numGhosts globally
    parser.add_option('-k', '--numGhosts', type='int', dest='numGhosts',
                      help=default('The maximum number of ghosts to use'), default=4)
    parser.add_option('-z', '--zoom', type='float', dest='zoom',
                      help=default('Zoom the size of the graphics window'), default=1.0)
    parser.add_option('-f', '--fixRandomSeed', action='store_true', dest='fixRandomSeed',
                      help='Fixes the random seed to always play the same game', default=False)
    ## TODO: Merge with record from capture.py
    parser.add_option('--record', action='store_true', dest='record',
                      help='Writes game histories to a file (named by the time they were played)', default=False)
    ## TODO: Add Record log
    parser.add_option('--replay', dest='replay',
                      help='A recorded game file (pickle) to replay', default=None)
    parser.add_option('-a','--agentArgs',dest='agentArgs',
                      help='Comma separated values sent to agent. e.g. "opt1=val1,opt2,opt3=val3"')
    parser.add_option('-x', '--numTraining', dest='numTraining', type='int',
                      help=default('How many episodes are training (suppresses output)'), default=0)
    parser.add_option('--frameTime', dest='frameTime', type='float',
                      help=default('Time to delay between frames; <0 means keyboard'), default=0.1)
    parser.add_option('-c', '--catchExceptions', action='store_true', dest='catchExceptions',
                      help='Turns on exception handling and timeouts during games', default=False)
    parser.add_option('--timeout', dest='timeout', type='int',
                      help=default('Maximum length of time an agent can spend computing in a single game'), default=30)
    parser.add_option('-r', '--red', help=default('Red team'),
                    default=os.path.join(DIR_SCRIPT, 'baselineTeam')),
    parser.add_option('--redPackage', help="Submission package containing red teams player agents and team definition"),
    parser.add_option('-b', '--blue', help=default('Blue team'),
                        default=os.path.join(DIR_SCRIPT, 'baselineTeam')),
    parser.add_option('--bluePackage', help="Submission package containing blue teams player agents and team definition"),
    parser.add_option('--singlePackage', help="Submission package containing single player agents"),
    parser.add_option('--redName', help=default('Red team name'),
                        default='Red')
    parser.add_option('--blueName', help=default('Blue team name'),
                        default='Blue')
    parser.add_option('--redOpts', help=default('Options for red team (e.g. first=keys)'),
                        default='')
    parser.add_option('--blueOpts', help=default('Options for blue team (e.g. first=keys)'),
                        default='')
    parser.add_option('--keys0', help='Make agent 0 (first red player) a keyboard agent', action='store_true',default=False)
    parser.add_option('--keys1', help='Make agent 1 (second red player) a keyboard agent', action='store_true',default=False)
    parser.add_option('--keys2', help='Make agent 2 (first blue player) a keyboard agent', action='store_true',default=False)
    parser.add_option('--keys3', help='Make agent 3 (second blue player) a keyboard agent', action='store_true',default=False)

    parser.add_option('-Q', '--superQuiet', action='store_true', dest="superQuiet",
                        help='Same as -q but agent output is also suppressed', default=False)

    parser.add_option('-i', '--maxIterations', type='int', dest='maxIterations',
                        help=default('TIME limit of a game in moves'), default=20000, metavar='TIME')
    parser.add_option('--setRandomSeed', type='str',
                        help='Sets the random seed to a the given string')
    
    parser.add_option('--recordLog', action='store_true',
                        help='Writes game log  to a file (named by the time they were played)', default=False)
    parser.add_option('--replayq', default=None,
                        help='Replays a recorded game file without display to generate result log.')
    parser.add_option('--delayStep', type='float', dest='delayStep',
                        help=default('Delay step in a play or replay.'), default=0.03)
    parser.add_option('--createNewTeam', action='store_true', help='Creates a new team, given a team name and the names of the agents')
    parser.add_option('--createSubmission', action='store_true', help='Creates a new submission given the gamemode and either the agent- or team-name')                      
    
    ## Separating known options from unknown arguments and throwing an error when an unknown argument is encountered
    options, unknownArgs = parser.parse_args(argv)
    
    ## Some functions, like createNewAgent allow for one arg. We pass it on and filter it out afterwards
    if len(unknownArgs) > 3:
        raise Exception('Command line input not understood: ' + str(unknownArgs))
    optionsDict:dict = options.__dict__
    
    ## Creating new agent if asked to
    if optionsDict.get('createNewAgent') == True:
        if unknownArgs:
            createAgent(unknownArgs[0], optionsDict.get('mode'))
        else:
            createAgent()
        return
    ## Creating new team
    elif optionsDict.get('createNewTeam') == True:
        if unknownArgs.__len__() == 3:
            createTeam(unknownArgs[0], unknownArgs[1], unknownArgs[2])
        else:
            createTeam()
        return
    elif optionsDict.get('createSubmission') == True:
        if unknownArgs:
            createSubmission(unknownArgs[0], optionsDict.get('mode'))
        else:
            createSubmission()
        return
    
    if len(unknownArgs) != 0:
        raise Exception('Command line input not understood: ' + str(unknownArgs))
    
    ## Retrieving the gameMode
    mode:str = optionsDict['mode']
    optionsDict = generateOptionsForMode(mode, optionsDict)

    availableRedCaptureTeams = captureTeams
    availableBlueCaptureTeams = captureTeams
    availableSingleAgents = pacmanAgents
    if options.redPackage:
        imported_module = importlib.import_module(options.redPackage)
        availableRedCaptureTeams = imported_module.captureTeams

    if options.bluePackage:
        imported_module = importlib.import_module(options.bluePackage)
        availableBlueCaptureTeams = imported_module.captureTeams

    if options.singlePackage:
        imported_module = importlib.import_module(options.singlePackage)
        availableSingleAgents = imported_module.pacmanAgents

    if mode == 'pacman':
        ## Include Sanity Checks for pacman here
        optionsDict['pacman'] = parseAgentName(optionsDict.get('pacman'))
        optionsDict['ghosts'] = parseAgentName(optionsDict.get('ghosts'))
        ## End Sanity Checks
        pacman.doRunPacman(optionsToKwargs(optionsDict), pacmanAgents=availableSingleAgents)
    elif mode == 'capture':
        ## Include Sanity Checks for capture here
        optionsDict['red'] = parseTeamName(optionsDict.get('red'))
        optionsDict['blue'] = parseTeamName(optionsDict.get('blue'))
        ## End Sanity Checks
        capture.doRunCapture(optionsToKwargs(optionsDict), captureTeamsRed=availableRedCaptureTeams, captureTeamsBlue=availableBlueCaptureTeams)

    ##//TODO: -n for name, -m for mode in createNewAgent
    


if __name__ == "__main__":
    
    readCommand(sys.argv[1:])