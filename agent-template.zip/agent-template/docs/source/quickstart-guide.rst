.. _quickstart:

How to AIxercise
================

This section will help you set up your AIxercise environment. At the
beginning, you only need your computer. In the end, you will be able to
play a simple round of single player Pacman. ## Installation

**This guide assumes that you run a distribution of GNU/Linux.** If you
don’t, we suggest that you install one or run it in a virtual machine.
Common choices for beginners are `Ubuntu
Desktop <https://ubuntu.com/#download>`__ or `Fedora
Workstation <https://getfedora.org/en/workstation/>`__. The
distribution-specific commands in this guide work with Ubuntu-based
systems. A quick google search will find you equivalent commands for
your Distribution. If you are certain that you have python3,
python-is-python3 and pipenv installed, you can skip to `Running
Pacman <#running-pacman>`__. While it should be possible to run this on
Windows, you will have to figure out the installation procedure
yourself. Check out Anaconda to get started with python on Windows.

Prepare your system
-------------------

Run the command ``python``. If you get an error, install python3 and
python-is-python3. In Ubuntu-based Systems , run the commands:

.. code:: shell

   sudo apt-get install python3
   sudo apt-get install python-is-python3

If everything went well, typing ``python`` into the terminal should
start the python interpreter. Enter ``exit()`` to leave it again.

-  To install `Pipenv <https://pipenv.pypa.io/en/latest/>`__, run the
   command

.. code:: shell

   sudo pip install pipenv

Preparing PacMan
----------------

Download and extract the source code. Let’s assume you unpacked the
sources into ``/home/user/Documents/AIxercise``. Inside ``AIxercise``
you find a file called ``Pipfile``. Open a terminal window and use
``cd`` to get to the folder containing the AIxercise source files.

.. code:: shell

   `cd /home/user/Documents/AIxercise`

-  To install all dependencies required for using AIxercise, make sure
   you are still in the folder containing ``pipfile`` and run

.. code:: shell

   pipenv install

Running single-player Pacman for the first time
-----------------------------------------------

After you have finished this guide, you are really up and running and
can play a little game of Pacman. Run the following command:

.. code:: shell

   pipenv run python cli.py -m pacman -p KeyboardAgent -g RandomGhost -l testPacman

You should see a little screen on which you can play Pacman using the
WASD keys.

Singleplayer: Pacman
--------------------

In the above section, you already saw how to run a simple game of
Pacman. This section explains the command

.. code:: shell

   pipenv run python cli.py -m pacman -p KeyboardAgent -g RandomGhost -l testPacman

in detail.

-  ``pipenv run python cli.py`` starts the command-line interface for
   AIxercise using all the dependencies that you find inside the
   pipfile. It has more functions than explained here, but you won’t
   need them for this course.
-  ``-m pacman`` selects the **mode** in which the game is run. During
   the course of this lecture, you will find that other gamemodes exist.
   In this example, it starts it in singleplayer-pacman mode. This means
   that only one Pacman-agent exists and all other agents are ghosts.
   However, Pacman does not always have to be controlled by keyboard
   inputs.
-  ``-p KeyboardAgent`` selects the Agent-class in the source-code that
   controls **Pacman**\ ’s behavior. In this example, Pacman is
   controlled using keyboard inputs. If you instead type
   ``-p GreedyAgent``, Pacman is controlled automatically and selects
   the next step by evaluating which actions would lead to the best next
   score and picking one of those actions randomly. If no food-dots are
   directly next to Pacman, GreedyAgent therefore picks a random action
   and runs around without any pattern.
-  ``-g RandomGhost`` specifies the **ghost**-Agent-class that tries to
   defeat Pacman. RandomGhost behaves completely random, but you can
   have a more challenging game by typing ``-g DirectionalGhost``
-  ``-l testPacman`` chooses the **layout** that the game is played on.
   While testPacman is quite a small map, you can type
   ``-l defaultPacman`` to play on a larger one.

Creating Single-player Agents
-----------------------------

You have seen already that Pacman and ghosts are controlled by
Agent-classes. This section explains how you can create your own agents
and modify them.

-  Run the command ``pipenv run python cli.py --createNewAgent`` and
   follow the instructions given in the terminal. It should look
   something like this:

.. code:: shell

   pipenv run python cli.py --createNewAgent
   Enter the Name of the new Agent: ExampleAgent
   Enter the Mode this new Agent is for (pacman/capture): pacman
   Created new agent at: pacman/agents/exampleAgent/exampleAgents.py

-  You find your freshly created agent in the
   ``AIxercise/agents``-folder:

.. code:: python

   #############################################################################
   ###                          Imports                                      ###
   #############################################################################
   from core.game import Agent, Directions
   from core import util, game

   #############################################################################
   ###                          Implementation                               ###
   #############################################################################
   class ExampleAgent(Agent):
       def getAction(self, state):
           ## TODO: Implement
           return Directions.STOP

-  As you can see the ExampleAgent class has been created for you. All
   you have to do is to edit the ``getAction``- function. Check out the
   provided agents for guidance.

Playing Pacman in Capture Mode
------------------------------

In capture mode you control not just one but two Pacmen which form a
team. Run your first match by executing:

::

   pipenv run python cli.py -m capture -r BaselineTeam -b BaselineTeam --keys0 -lRANDOM19991

-  ``-m capture`` selects the capture game variant
-  ``-r BaselineTeam`` selects the baselineTeam for the red team. Once
   you have created more teams, you can also type this
-  ``-b BaselineTeam`` selects the baselineTeam for the blue team
-  ``--keys0`` controls Pacman with index 0 using the ``KeyboardAgent``.
   You can choose any index from 1 to 3.
-  ``-lRANDOM19991`` generates a random game area (in capture mode only
   currently) using seed 19991

Creating Capture Agents and Teams
---------------------------------

Similar to Pacman, you can create your own agents and give them a unique
behavior in Capture. To use those agents, you have to create a
CaptureTeam containing them. This section explains how to do both.

Capture Agents
~~~~~~~~~~~~~~

Generating Capture agents is very similar to creating Pacman agents.

-  Run the command ``pipenv run python cli.py --createNewAgent`` and
   follow the instructions given in the terminal. It should look
   something like this:

.. code:: shell

   pipenv run python cli.py --createNewAgent
   Enter the Name of the new Agent: ExampleAgent
   Enter the Mode this new Agent is for (pacman/capture): capture
   Created new agent at: pacman/agents/exampleAgent/exampleAgents.py

-  You can now find your new agent in the ``AIxercise/agents``-folder:

.. code:: python

   #############################################################################
   ###                          Imports                                      ###
   #############################################################################
   from core.game import Directions
   from agents.common.captureAgents import CaptureAgent
   from core import util, game

   #############################################################################
   ###                          Implementation                               ###
   #############################################################################
   class ExampleAgent(CaptureAgent):
       def chooseAction(self, state):
           ## TODO: Implement
           return Directions.STOP

       ## Remove #s below if you want to initialize your CaptureAgent differently
       # def registerInitialState(self, gameState):
       #     ## Your initialization code here:
       #     raise Exception('Function registerInitialState was uncommented, but not implemented in ' + self.__class__.__name__)
       #     ## DONT REMOVE THIS LINE
       #     CaptureAgent.registerInitialState(self, gameState)

       ## Remove #s below if you want to modify the getFeatures function
       # def getFeatures(self, gameState, action):
       #     ## Implement here
       #     raise Exception('Function getFeatures was uncommented, but not implemented in ' + self.__class__.__name__)

       ## Remove #s below if you want to modify the weights that are attributed to features
       # def getWeights(self, gameState, action):
       #     ## Implement here
       #     raise Exception('Function registerInitialState was uncommented, but not implemented in ' + self.__class__.__name__)

-  Just as with Pacman agents, this class has been generated for you.
   Theoretically, you only have to implement chooseAction. However,
   there are also functions that have been commented out, as they are
   optional but can be useful. See the other CaptureAgents for guidance
   on how to implement a CaptureAgent.

Teams
-----

To try out your own agents, you can just swap out the agents within the
``pacman/teams/baseline/baselineTeam.py``-file. Specifically, the
firstAgent and secondAgent in this portion:

.. code:: python

   class BaselineTeam(CaptureTeam):
     firstAgent = DefensiveReflexAgent
     secondAgent = OffensiveReflexAgent

can be changed to:

.. code:: python

   class BaselineTeam(CaptureTeam):
     firstAgent = ExampleAgent
     secondAgent = ExampleAgent

This way has some problems, though. First of all, you cannot use the
original BaselineTeam anymore. Secondly, you cannot have to different
teams battle at the same time. That’s why you can create your own teams
and give them proper names. This section explains how:

-  Run the command ``pipenv run python cli.py --createNewTeam``. This
   will guide you through the team creation process. It should look
   similar to this:

.. code:: shell

   pipenv run python cli.py --createNewTeam
   Enter the name of the Team: ExampleTeam
   Enter the name of the first CaptureAgent that should be in this team: Example1Agent
   Enter the name of the second CaptureAgent that should be in this team: Example2Agent
   Created new Team at: pacman/teams/exampleTeam/exampleTeam.py

Creating submissions
--------------------

This section explains how you can submit your work. In the end, you will
have a ``.zip``-file that you can upload to moodle.

-  Run the command ``pipenv run python cli.py --createSubmission`` and
   it will guide you through the process of creating a submission. It
   should look something like this:

.. code:: shell

   pipenv run python cli.py --createSubmission
   Enter the mode you want to create a submission for (pacman/capture):

-  At this point, you will have slightly different experiences, based on
   which mode you select. The next two subsections will show you both
   (but once you have seen one, will probably be able to do the other as
   well).

Submissions for Singleplayer Pacman
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

After entering pacman, you will be asked to type in the name of the
agent you want to submit. The whole process will look like this:

.. code:: shell

   pipenv run python cli.py --createSubmission
   Enter the mode you want to create a submission for (pacman/capture): pacman
   Enter the name of the Agent you want to submit: ExampleAgent
   ExampleAgent has been packaged as a submission and saved to submission.zip

Now you should find your submission as the file
``AIxercise/submission.zip``. **Don’t touch it**, but upload it to
moodle as is.

Submissions for Capture
~~~~~~~~~~~~~~~~~~~~~~~

Instead of just submitting the agents, you will have to submit a whole
capture team. Therefore the command line will ask you for the name of
the team.

.. code:: shell

   pipenv run python cli.py --createSubmission
   Enter the mode you want to create a submission for (pacman/capture): capture
   Enter the name of the Team you want to submit: ExampleTeam
   ExampleTeam has been packaged as a submission and saved to submission.zip

Now you should find your submission as the file
``AIxercise/submission.zip``. **Don’t touch it**, but upload it to
moodle as is.
