pacman.teams package
====================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   pacman.teams.baseline

Module contents
---------------

.. automodule:: pacman.teams
   :members:
   :undoc-members:
   :show-inheritance:
