pacman namespace
================

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   pacman.agents
   pacman.core
   pacman.graphics
   pacman.layouts
   pacman.teams

Submodules
----------

pacman.replay module
--------------------

.. automodule:: pacman.replay
   :members:
   :undoc-members:
   :show-inheritance:

pacman.textDisplay module
-------------------------

.. automodule:: pacman.textDisplay
   :members:
   :undoc-members:
   :show-inheritance:

pacman.unpack module
--------------------

.. automodule:: pacman.unpack
   :members:
   :undoc-members:
   :show-inheritance:
