pacman.teams.baseline package
=============================

Submodules
----------

pacman.teams.baseline.baselineTeam module
-----------------------------------------

.. automodule:: pacman.teams.baseline.baselineTeam
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: pacman.teams.baseline
   :members:
   :undoc-members:
   :show-inheritance:
