.. AIxercise documentation master file, created by
   sphinx-quickstart on Tue Apr 12 14:50:14 2022.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to AIxercise's documentation!
=====================================

Here you find some more information on the AIxercise code base. Thanks to RMIT University and UC Berkeley for
open-sourcing their code. See :ref:`Licensing`.

There are two game variants: the classic single-player variant and a two-player capture the flag variant.

Getting Started
----------
Checkout :ref:`quickstart` to get started.


Quickstart
----------

Let’s get you started.

*This short guide should work independent of your OS but is only
thoroughly tested on Linux (Fedora 34 to be precise). We expect you to
be familiar with basic command-line commands.*

Local setup
~~~~~~~~~~~

First, clone the repository and install its dependencies. We recommend
you to get familiar with git if you aren’t, yet. It helps collaboration
with your team!

.. code:: bash

   pipenv install

Now, generate a new agent

.. code:: bash

   pipenv run python cli.py --createNewAgent

This will guide you through creating a new agent and tell you where it
has been placed.

Finally, to package your agent run

.. code:: bash

   pipenv run python cli.py --createSubmission

where the last parameter is the path to the directory containing your
agent module.

To run a single-player game using the greedyAgent use the following
command. You can also use a ``keyboardAgent`` to manually control
Pacman.

.. code:: shell

   pipenv run python cli.py -m pacman -p greedyAgent -l defaultPacman

To run a capture game run

.. code:: shell

   pipenv run python cli.py -m capture -l defaultCapture



GameStates
----------
All PacmanAgents must override the following function which receives the current `GameState`.

.. autosummary::

   pacman.core.game.Agent.getAction

There are two game variants, namely Classic Pacman and Capture Pacman, for which there are
slightly different GameState classes.

Classic Pacman GameState
~~~~~~~~~~~~~~~~~~~~~~~~~
Checkout the following class if you are implementing a Classic Pacman agent.

.. autosummary::

   pacman.core.pacman.GameState

Capture Pacman GameState
~~~~~~~~~~~~~~~~~~~~~~~~~
Checkout the following class if you are implementing a Capture Pacman agent.

.. autosummary::

   pacman.core.capture.GameState

Base Class For Capture Agents
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
There is a base class which you may override to make your life easier when
developing a capture agent.

.. autosummary::

   pacman.agents.common.captureAgents.CaptureAgent

Core modules
============

.. toctree::
   :glob:
   :maxdepth: 2
   :caption: Contents:

   licensing.rst
   quickstart-guide.rst
   pacman/pacman.core.rst
   pacman/pacman.agents.common.rst


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
