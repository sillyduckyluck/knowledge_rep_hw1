.. _licensing:

Licensing
=========

This code buikds upon `RMIT University’s enhancements <https://github.com/AI4EDUC/pacman-contest-agent>`__ of `UC
Berkeley’s Pacman Capture the Flag <http://ai.berkeley.edu/contest.html>`__ competition code. We are
very grateful for their work.

This version includes the following changes:

* Refactoring into multiple modules
* Add tooling for bootstrapping new agents
* Add tooling for creating submissions. NB: submissions created this way are not backwards compatible (yet). We do not use the existing competition cluster but develop a separate submission and competition scheduling system.

Original Licensing Information from UC Berkeley
--------

Please do not distribute or publish solutions to this project. You are free to use and extend these projects for educational purposes. The Pacman AI projects were developed at UC Berkeley, primarily by
John DeNero (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).  Student side autograding was added by Brad Miller, Nick Hay, and Pieter Abbeel (pabbeel@cs.berkeley.edu).

For more info, see http://inst.eecs.berkeley.edu/~cs188/sp09/pacman.html)

You are free to use or extend these projects for educational purposes provided that

1. you do not distribute or publish solutions,
2. you retain this notice,
3. you provide clear attribution to UCB Berkeley, including a link to http://ai.berkeley.edu.
