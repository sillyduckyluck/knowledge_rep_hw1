#############################################################################
###                  DO NOT EDIT!!!!!!!!!!                                ###
#############################################################################
## Upon creating a new team, this file extends itself


from .baseline.baselineTeam import BaselineTeam
captureTeams:list = []
captureTeams.append(BaselineTeam)
