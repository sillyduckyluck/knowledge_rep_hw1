#############################################################################
###                          Imports                                      ###
#############################################################################
from pacman.core.game import Agent, Directions
from pacman.core import util, game

import random

# NB! If you create any additional files, only create them in this folder! You can import them the following way
# from . import yourModule
# or
# from .yourModule import yourFunction

#############################################################################
###                          Implementation                               ###
#############################################################################
class RandomAgent(Agent):
    def getAction(self, state):
        actions = state.getLegalActions()
        return random.choice(actions)
