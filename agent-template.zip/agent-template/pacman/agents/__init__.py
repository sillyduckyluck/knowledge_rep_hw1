#############################################################################
###                  DO NOT EDIT!!!!!!!!!!                                ###
#############################################################################
## Upon creating a new agent, this file extends itself

#############################################################################
###                           Imports                                     ###
#############################################################################
##imports
from .common.captureAgents import DefensiveReflexAgent, OffensiveReflexAgent
from .ghost.ghostAgents import DirectionalGhost, RandomGhost
from .keyboard.keyboardAgents import KeyboardAgent, KeyboardAgent2
from .pacman.pacmanAgents import GreedyAgent, LeftTurnAgent
from .randomAgent.randomAgents import RandomAgent
##END

#############################################################################
###                           Pacman Agents                               ###
#############################################################################
##pacmanAgents
pacmanAgents:list = []
pacmanAgents.append(LeftTurnAgent)
pacmanAgents.append(GreedyAgent)
pacmanAgents.append(KeyboardAgent)
pacmanAgents.append(KeyboardAgent2)
pacmanAgents.append(RandomAgent)
#END

#############################################################################
###                           Capture Agents                              ###
#############################################################################
##captureAgents
captureAgents:list = []
captureAgents.append(DefensiveReflexAgent)
captureAgents.append(OffensiveReflexAgent)
#END

#############################################################################
###                           Capture Agents                              ###
#############################################################################
##ghostAgents
ghostAgents:list = []
ghostAgents.append(RandomGhost)
ghostAgents.append(DirectionalGhost)

