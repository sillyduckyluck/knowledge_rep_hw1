from ..agents import pacmanAgents, captureAgents, ghostAgents
from ..teams import captureTeams

allAgentsAllTeams:list = pacmanAgents.copy()
'''All Names of Agents that have been defined so far'''
allAgentsAllTeams.extend(captureAgents)
allAgentsAllTeams.extend(ghostAgents)
allAgentsAllTeams.extend(captureTeams)

def parseAgentName(aName:str) -> str:
    '''This function makes it easier to parse Agents by their name or their path. If a path is given, it is turned into the name of a class. The following names are translated into ExampleAgent:
    - ExampleAgent
    - Example (only if no agent with the classname 'Example' exists, otherwise, 'Example' is returned)
    - ExampleAgents (only if no agent with the classname 'ExampleAgents' exists, otherwise, 'ExampleAgents' is returned)
    - exampleAgent
    - example (only if no agent with the classname 'Example' exists, otherwise, 'Example' is returned)
    - exampleAgents (only if no agent with the classname 'ExampleAgents' exists, otherwise, 'ExampleAgents' is returned)
    - agents/example/exampleAgents.py
    - agents/example/exampleAgents
    - agents/example/ExampleAgents.py
    - agents/example/ExampleAgents
    '''
    ## Agent names are not allowed to contain a '/'. Therefore, this must be a path.
    if aName.__contains__('/'):
        aName = aName.split('/')[-1]
        ## From this point on, the only valid forms aName can have are
        ## exampleAgents
        ## exampleAgents.py
        ## ExampleAgents
        ## ExampleAgents.py
        if aName.endswith('.py'):
            aName = aName[-4]
        else:
            aName = aName[-1]
        ## exampleAgent
        ## ExampleAgent
        
            
    else:
        ## From this point on, the only valid forms aName can have are
        ## ExampleAgent
        ## Example
        ## ExampleAgents
        ## exampleAgent
        ## example
        ## exampleAgents
        if aName.endswith('Agents'):
            ## If an agent named 'ExampleAgents' exists, it returns ExampleAgents
            if aName[0].upper() + aName[1:] in [str(agentOrTeam) for agentOrTeam in allAgentsAllTeams]:
                return aName[0].upper() + aName[1:]
            
            ## ExampleAgents
            ## exampleAgents
            aName = aName[:-1]
            ## ExampleAgent
            ## exampleAgent
        elif not aName.endswith('Agent'):
            ## If an agent named 'Example' exits, this name  is returned
            if aName[0].upper() + aName[1:] in [agentOrTeam.__name__ for agentOrTeam in allAgentsAllTeams]:
                return aName[0].upper() + aName[1:]
            
            ## Example
            ## example
            aName += 'Agent'
            ## ExampleAgent
            ## exampleAgent
        else:
            ## exampleAgent
            ## ExampleAgent
            pass
    ## exampleAgent
    ## ExampleAgent
    aName = aName[0].upper() + aName[1:]
    ## ExampleAgent
    return aName
        
def parseTeamName(tName:str) -> str:
    '''This function makes it easier to parse Team by their name or their path. If a path is given, it is turned into the name of a class. The following names are translated into ExampleTeam:
    - ExampleTeam
    - Example (only if no team with the classname 'Example' exists, otherwise, 'Example' is returned)
    - exampleTeam
    - example (only if no team with the classname 'Example' exists, otherwise, 'Example' is returned)
    - agents/example/exampleTeam
    - agents/example/ExampleTeam
    '''
    if tName.__contains__('/'):
        ## The user input a path
        ## The last element of the path is the filename
        tName = tName.split('/')[-1]
        ## exampleTeam
        ## ExampleTeam
    else:
        ## ExampleTeam
        ## Example
        ## exampleTeam
        ## example
        if not tName.endswith('Team'):
            tName += 'Team'
        ## ExampleTeam
        ## exampleTeam
    
    ## ExampleTeam
    ## exampleTeam
    tName = tName[0].upper() + tName[1:]
    ## ExampleTeam
    return tName

illegalNameSubstrings = ['/']
'''All substrings that a name cannot contain.
- '/' is not permitted, because it can be misunderstood as a path'''

def isLegalName(name:str)->bool:
    '''Performs tests on the name to make sure the name follows all rules. If the name doesent, it returns False'''
    for substring in illegalNameSubstrings:
        if name.__contains__(substring):
            return False
    return True

def nameExists(name:str)->bool:
    '''Returns True if a given name already exists'''
    allAgentsAllTeamsNames = [ag.__name__ for ag in allAgentsAllTeams]
    return ((name[0].upper() + name[1:]) in allAgentsAllTeamsNames or (name[0].upper() + name[1:] + 'Agent') in allAgentsAllTeamsNames or (name[0].upper() + name[1:]+ 'Team') in allAgentsAllTeamsNames)

def isCaptureAgent(agentName:str) -> bool:
    '''Returns True if a CaptureAgent class with this name exists'''
    return agentName in [captureAgent.__name__ for captureAgent in captureAgents]

def fileOrDirName(name:str) -> str:
    '''A method that enforces file and dir naming conventions in python, given a filename.
    - Makes sure the first letter is lower case'''
    return name[0].lower() + name[1:]