import os
import pystache
from ..agents import captureAgents
from .cliUtil import parseAgentName, isLegalName, parseTeamName, nameExists, illegalNameSubstrings, isCaptureAgent, fileOrDirName

teamTemplate = '''#############################################################################
###                          Imports                                      ###
#############################################################################
from ..baseline.baselineTeam import CaptureTeam
from ...agents import {{agent1Name}}, {{agent2Name}}

#############################################################################
###                          Team                                         ###
#############################################################################
class {{teamName}}(CaptureTeam):
    firstAgent = {{agent1Name}}
    secondAgent = {{agent2Name}}'''
def createTeam(teamNameInput:str = None, agent1NameInput:str = None, agent2NameInput:str = None):
    
    ## Parsing team name
    if teamNameInput == None:
        teamNameInput = input("Enter the name of the Team: ")
    teamName = parseTeamName(teamNameInput)
    while nameExists(teamName) or not isLegalName(teamNameInput):
        if nameExists(teamName):
            teamNameInput = input("A team with the name "+teamNameInput+" ("+teamName+" according to naming convention) already exists. Please enter another team name: ")
        elif not isLegalName(teamNameInput):
            teamNameInput = input("The name "+teamNameInput+" is not allowed. Please make sure that no combination of the following items is part of the name: "+ str(illegalNameSubstrings) + ": ")
        teamName = parseTeamName(teamNameInput)
        
    ## Parsing first agent name
    if agent1NameInput == None:
        agent1NameInput = input("Enter the name of the first Agent: ")
    agent1Name = parseAgentName(agent1NameInput)
    while (not isCaptureAgent(agent1Name)) or (not isLegalName(agent1NameInput)):
        if not isCaptureAgent(agent1Name):
            agent1NameInput = input("The agent "+ agent1NameInput + " ("+agent1Name+" according to naming convention) does not exist. Please enter one of the following names: "+str([ca.__name__ for ca in captureAgents])+": ")
        elif not isLegalName(agent1NameInput):
            agent1NameInput = input("The name "+agent1NameInput+" is not allowed. Please make sure that no combination of the following items is part of the name: "+ str(illegalNameSubstrings) + ": ")
        agent1Name = parseAgentName(agent1NameInput)
        
    ## Parsing 2nd Agent name
    if agent2NameInput == None:
        agent2NameInput = input("Enter the name of the second Agent: ")
    agent2Name = parseAgentName(agent2NameInput)
    while (not isCaptureAgent(agent2Name)) or (not isLegalName(agent2NameInput)):
        if not isCaptureAgent(agent2Name):
            agent2NameInput = input("The agent "+ agent2NameInput + " ("+agent2Name+" according to naming convention) does not exist. Please enter one of the following names: "+str([ca.__name__ for ca in captureAgents])+": ")
        elif not isLegalName(agent2NameInput):
            agent2NameInput = input("The name "+agent2NameInput+" is not allowed. Please make sure that no combination of the following items is part of the name: "+ str(illegalNameSubstrings) + ": ")
        agent2Name = parseAgentName(agent2NameInput)
    
    pathToNewDir = createTeamDir(teamName)
    createTeamInitFile(pathToNewDir)
    createTeamFile(teamName=teamName, pathToTeamDir=pathToNewDir, agent1Name= agent1Name, agent2Name = agent2Name)
    appendToTeamCaptureTeamsList(teamName)
    
    print("Created team: "+teamName+" with agent 1: "+ agent1Name + " and agent 2:" + agent2Name)

def createTeamDir(teamName:str) -> str:
    '''Creates the directory for a team and returns the path to it'''
    parentDir = 'pacman/teams/'
    pathToNewDir = os.path.join(parentDir,fileOrDirName(teamName))
    os.mkdir(pathToNewDir)
    return pathToNewDir

def createTeamInitFile(pathToTeamDir:str):
    '''Creates the __init__.py for a team package'''
    initFile = open(pathToTeamDir+'/__init__.py', 'x')
    initFile.close()
    
def createTeamFile(teamName:str, pathToTeamDir:str, agent1Name:str, agent2Name:str):
    teamFileName = pathToTeamDir+'/'+fileOrDirName(teamName)+'.py'
    teamFile = open(teamFileName, 'x')
    teamData = {'teamName':teamName, 'agent1Name': agent1Name, 'agent2Name': agent2Name}
    teamFileData = pystache.render(teamTemplate, teamData)
    teamFile.write(teamFileData)
    teamFile.close()

def appendToTeamCaptureTeamsList(teamName):
    '''Appends a team to the captureTeams list, so it can be loaded by capture.'''
    initFile = open('pacman/teams/__init__.py', 'a')
    pystacheContext = {'teamFileName': fileOrDirName(teamName), 'teamName': teamName}
    teamAppendTemplate = '''
##{{teamName}}
from .{{teamFileName}}.{{teamFileName}} import {{teamName}}
captureTeams.append({{teamName}})'''
    initFile.write(pystache.render(teamAppendTemplate, pystacheContext))
    initFile.close()
    
            