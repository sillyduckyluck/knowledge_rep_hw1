import pystache
from ..agents import pacmanAgents, captureAgents
from ..teams import captureTeams
import os
from pacman.core.cliUtil import isLegalName, nameExists, illegalNameSubstrings, parseAgentName

#############################################################################
###                          CLI Utility                                  ###
#############################################################################
pacmanAgentFileContent:str = '''#############################################################################
###                          Imports                                      ###
#############################################################################
from pacman.core.game import Agent, Directions
from pacman.core import util, game

# NB! If you create any additional files, only create them in this folder! You can import them the following way
# from . import yourModule
# or
# from .yourModule import yourFunction

#############################################################################
###                          Implementation                               ###
#############################################################################
class {{agentName}}(Agent):
    def getAction(self, state):
        ## TODO: Implement
        return Directions.STOP'''

captureAgentFileContent:str = '''#############################################################################
###                          Imports                                      ###
#############################################################################
from pacman.core.game import Directions
from pacman.agents.common.captureAgents import CaptureAgent
from pacman.core import util, game

# NB! If you create any additional files, only create them in this folder! You can import them the following way
# from . import yourModule
# or
# from .yourModule import yourFunction

#############################################################################
###                          Implementation                               ###
#############################################################################
class {{agentName}}(CaptureAgent):
    def chooseAction(self, state):
        ## TODO: Implement
        return Directions.STOP
    
    ## Remove #s below if you want to initialize your CaptureAgent differently
    # def registerInitialState(self, gameState):
    #     ## Your initialization code here:
    #     raise Exception(\'Function registerInitialState was uncommented, but not implemented in \' + self.__class__.__name__)
    #     ## DONT REMOVE THIS LINE
    #     CaptureAgent.registerInitialState(self, gameState)
    
    ## Remove #s below if you want to modify the getFeatures function
    # def getFeatures(self, gameState, action):
    #     ## Implement here
    #     raise Exception(\'Function getFeatures was uncommented, but not implemented in \' + self.__class__.__name__)
    
    ## Remove #s below if you want to modify the weights that are attributed to features
    # def getWeights(self, gameState, action):
    #     ## Implement here
    #     raise Exception(\'Function registerInitialState was uncommented, but not implemented in \' + self.__class__.__name__)'''

def createAgent(agentNameInput:str = None, mode:str = None) -> None:
    '''
    Guides the user through the creation of a new agent. After the name and mode have been provided, it creates a new folder containing an __init__.py and a .py-file containing a working template for the agent inside the /agents/-folder 
    '''
        
    
    if agentNameInput == None:
        agentNameInput:str = input('Enter the Name of the new Agent: ')
    
    ## Removing the suffix "Agent" if it exists
    agentName = parseAgentName(agentNameInput)
    
    ## Checking if this agent already exists
    while nameExists(agentName) or not isLegalName(agentNameInput):
        if nameExists(agentName):
            agentNameInput = input("The agent " + agentNameInput + "("+agentName+" according to naming convention) already exists. Please input another name,  or press Crtl+D to exit: ")
        else:
            agentNameInput = input("The name " + agentNameInput + " is not allowed. Please make sure that it does not contain any substrings from this list: " + str(illegalNameSubstrings))
        agentName = parseAgentName(agentNameInput)
    
    if mode == None:
        mode:str = input('Enter the Mode this new Agent is for (pacman/capture): ').lower()
    ## As long as no correct input has been given, we give the user a chance to correct their answer
    while not mode in ['pacman', 'capture']:
        mode = input('The mode \''+mode+'\' does not exist. Either enter \'pacman\' or \'capture\', or press Crtl+D to exit: ')
    ## Make the first char of the agentName lowercase, because it will be a filename in lowerCamelCase
    agentName = agentName[0].lower() + agentName[1:]
    
    ## Create Directory and files
    parentDir = 'pacman/agents/'
    pathToNewDir = os.path.join(parentDir,agentName)
    os.mkdir(pathToNewDir)
    
    ## Init file (for initialization code, marking it as a package)
    initFile = open(os.path.join(parentDir,agentName)+'/__init__.py', 'x')
    initFile.close()
    
    ## Creating the agent file
    agentsFileName = os.path.join(parentDir,agentName)+'/'+agentName+'s.py'
    agentsFile = open(agentsFileName, 'x')
    
    ## Make the first char of the agentName uppercase, because it will be a class name
    agentName = agentName[0].upper() + agentName[1:]
    agentData = {'agentName':agentName}
    agentFileData:str = ''
    if mode == 'pacman':
        agentFileData = pystache.render(pacmanAgentFileContent, agentData)
    elif mode == 'capture':
        agentFileData = pystache.render(captureAgentFileContent, agentData)
    agentsFile.write(agentFileData)
    agentsFile.close()
    
    ## Writing agent into list in agents/__init__.py
    agentsInitFile = open('pacman/agents/__init__.py', 'r')
    agentsInitFileLines:list = agentsInitFile.readlines()
    agentsInitFile.close()
      
    ## Adding Import Statement
    index = 0
    for line in agentsInitFileLines:
        index = index + 1
        if line == "##imports\n":
            break
    while agentsInitFileLines[index] != '##END\n':
        index = index + 1
    agentsInitFileLines.insert(index, "from ." + agentName[0].lower() + agentName[1:] + "." + agentName[0].lower() + agentName[1:] + "s" + " import " + agentName[0].upper() + agentName[1:] + "\n")
    
    ## Adding to respective List
    index = 0
    if(mode == 'pacman'):
        for line in agentsInitFileLines:
            index = index + 1
            if line == '##pacmanAgents\n': 
                break
        index += pacmanAgents.__len__() + 1
        agentsInitFileLines.insert(index, "pacmanAgents.append(" + agentData['agentName'] + ")\n")
    elif(mode == 'capture'):
        for line in agentsInitFileLines:
            index = index+1
            if line == '##captureAgents\n':
                break
        index += captureAgents.__len__() +1
        agentsInitFileLines.insert(index, "captureAgents.append(" + agentData['agentName'] + ")\n")
    agentsInitFile = open('pacman/agents/__init__.py', 'w')
    agentsInitFile.writelines(agentsInitFileLines)
    
    
    
    print('Created new agent at: '+agentsFileName)
