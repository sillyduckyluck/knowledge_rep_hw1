import os
from genericpath import exists
from zipfile import ZipFile
from ..agents import pacmanAgents, captureAgents
from .cliUtil import isLegalName, parseAgentName, parseTeamName, illegalNameSubstrings, fileOrDirName
from ..teams import captureTeams


def createSubmission(agentOrTeamNameInput:str = None, mode:str = None):
    if mode == None:
        mode = input('Enter the mode you want to create a submission for (pacman/capture): ')
    while not mode in ['pacman', 'capture']:
        mode = input(mode + ' is not a valid mode. Please enter either \'pacman\' or \'capture\'')
    
    if mode == 'pacman':
        path = createPacmanSubmission(agentOrTeamNameInput)
    else:
        path = createCaptureSubmission(agentOrTeamNameInput)
    
    print("Created submission (submission.zip)")

def createPacmanSubmission(agentNameInput):
    return _createSubmission(agentNameInput, pacmanAgents)

def _createSubmission(agentNameInput, agent_team_selection, mode="pacman"):
    className = "Agent"
    if mode == "capture":
        className = "Team"
    if agentNameInput == None:
        agentNameInput = input('Enter the name of the ' + className + '-class you want to submit: ')
    
    agentName = parseAgentName(agentNameInput)
    while (not isLegalName(agentNameInput)) or (not agentName in [ag.__name__ for ag in agent_team_selection]):
        if not isLegalName(agentNameInput):
            agentNameInput = input('The input '+agentNameInput+' is not allowed. Please make sure it does not include any of the following characters: '+str(illegalNameSubstrings)+': ')
        else:
            agentNameInput = input('The pacman-agent or team '+agentNameInput+'('+agentName+' according to naming convention) does not exist. Please enter another name: ')
        agentName = parseAgentName(agentNameInput)
    
    path = "pacman"

    with open(".submitted_agent", "w") as f:
        f.write(agentName)
        f.flush()
        f.close()
    
    zip_file = ZipFile('submission.zip', 'w')

    # taken from https://stackoverflow.com/a/1855118
    for root, dirs, files in os.walk(path):
        for file in files:
            zip_file.write(os.path.join(root, file),
                       os.path.relpath(os.path.join(root, file),
                                       os.path.join(path, '..')))

    zip_file.write('.submitted_agent')
    zip_file.write('__init__.py')

    zip_file.close()


def createCaptureSubmission(teamNameInput):
    return _createSubmission(teamNameInput, captureTeams, "capture")
